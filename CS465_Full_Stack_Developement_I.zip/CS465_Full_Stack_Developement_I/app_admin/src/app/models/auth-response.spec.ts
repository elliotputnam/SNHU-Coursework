import { AuthResponse } from './auth-response';

describe('AuthResponse', () => {
  it('should create an instance', () => {
    expect(new AuthResponse()).toBeTruthy();
  });
});
