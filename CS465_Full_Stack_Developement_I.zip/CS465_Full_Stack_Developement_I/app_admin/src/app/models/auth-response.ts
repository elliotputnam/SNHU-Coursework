export class AuthResponse {
  token: string;
  constructor() {
    this.token = '';
  }
}
