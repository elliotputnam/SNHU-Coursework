How do I approach designing software?

- I would like to approach designing software by analyzing the requirements and expectations first. It is important to understand the scope of the project to ensure I am fully equipped and working efficiently.

What new design skills has your work on the project helped you to craft?

- I was able to learn about how to implement shapes into complex designs. I took photos of the 3D objects I was to recreate and I added wireframes within them to simulate what shapes I may require which assisted in the speed of design.

How could tactics from your design approach be applied in future work?

- The approach was simple in that I took note of my requirements, set an acheivable goal, gave myself enough time to complete the task, and set forth working at a steady pace.

How do I approach developing programs?

- Very cautiously due to the fact that they are a complex organism so to speak and they can appear more simple than they are. As stated above, learn the requirements, prototype, research best practices and techniques that will aid in development.

How did iteration factor into your development?

- Every change I made, I ran the application to ensure my changes reflected what I wanted. 

How has your approach to developing code evolved throughout the milestones, which led you to the project’s completion?

- This course was short in respect to how long I have been developing my skills, so I would say not much changed during this timeframe. I learned more about C++ and gained more knowledge of that language in particular.

How do computational graphics and visualizations give you new knowledge and skills that can be applied in your future professional pathway?

- I plan to develop videogames so I can safety say that I will be incredibly useful to my future professional pathway. Or, if I decide to keep it a hobby, I will be well versed. 
